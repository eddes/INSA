# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 22:09:27 2026

@author: ewalther01
"""
from numba import njit
import numpy as np
import scipy.sparse as sp
from tqdm import tqdm

def fc_Euler_Implicit(Tinit, matrice_FoX, dt, simtime):
    # boucle Euler implicite
    t_range=np.arange(0,simtime,dt)
    T=Tinit
    for t in tqdm(t_range):
        T_plus = sp.linalg.spsolve(matrice_FoX, T)
        T=T_plus
    return T

def fc_Fouriers(k,rho,Cp,dt,dx,dy,cells_solide, cells_CL):
    nx,ny = k.shape[0],k.shape[1]
    FoS, FoN, FoE, FoW, u_diag = np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny))
    dxdy=dx*dy
    for m in range(len(cells_solide)):
        i,j = cells_solide[m, 0], cells_solide[m, 1]
        mCp=rho[i,j]*Cp[i,j]*dxdy
        FoS[i,j] = dx*dt/(mCp* 0.5*dy*(1/k[i+1,j] + 1/k[i,j]))
        FoN[i,j] = dx*dt/(mCp* 0.5*dy*(1/k[i-1,j] + 1/k[i,j]))
        FoE[i,j] = dy*dt/(mCp* 0.5*dx*(1/k[i,j+1] + 1/k[i,j]))
        FoW[i,j] = dy*dt/(mCp* 0.5*dx*(1/k[i,j-1] + 1/k[i,j]))
        u_diag[i,j] = 1-(FoS[i,j]+FoN[i,j]+FoE[i,j]+FoW[i,j])
    
    # pour les CL on doit mettre un coeff de 1 pour que T+ = T
    for m in range(len(cells_CL)):
        i,j = cells_CL[m, 0], cells_CL[m, 1]
        u_diag[i,j]=1
        
    return FoN, FoS, FoE, FoW, u_diag

# creation de
def fc_sparse_Fourier_explicite(FoN,FoS,FoE,FoW,u_diag, sparse=True):
    
    nx,ny=FoS.shape[0],FoS.shape[1]
    size, col = nx*ny, ny
    # on applatit les matrices en vecteurs
    FoS=FoS.flatten()
    FoN=FoN.flatten()
    FoE=FoE.flatten()
    FoW=FoW.flatten()
    u_diag=u_diag.flatten()
    
    #Décalage des diagonales pour faire correspondre les indices
    N_diag = np.roll(FoN,-col)
    S_diag = np.roll(FoS,+col)
    E_diag = np.roll(FoE,+1)
    W_diag = np.roll(FoW,-1)
    
    # Matrice pleine pour la forme
    if not sparse:
        matriceK = np.eye(size,k=-col)*N_diag \
                 + np.eye(size,k=-1)*W_diag \
                 + np.eye(size)*u_diag \
                 + np.eye(size,k=1)*E_diag \
                 + np.eye(size,k=col)*S_diag
    
    # Décalage des diagonales
    N_diag = N_diag[:-col]
    S_diag = S_diag[col:]
    E_diag = E_diag[1:]
    W_diag = W_diag[:-1]
    # On assemble
    mat_sparse = sp.diags(
            [N_diag, W_diag, u_diag, E_diag, S_diag],
            offsets=[-col,-1, 0, +1, +col],
            shape=(size, size)
        )
    
    # ensuite 
    if sparse:
        return mat_sparse
    else:
        return matriceK

# version naive du calcul "matriciel" : pour la compréhension du calcul mais pas efficace
@njit
def fc_VF_numba_Fo(cells_mur, T,Tplus,FoN,FoS,FoE,FoW,tsimu, dt):
    for t in np.arange(0, tsimu, dt):
        for ij in cells_mur :
            i,j = ij[0], ij[1]
            Tplus[i,j]= T[i,j]*(1-FoN[i,j]-FoS[i,j]-FoE[i,j]-FoW[i,j]) \
                + T[i+1,j]*FoS[i,j] + T[i-1,j]*FoN[i,j] \
                    + T[i,j+1]*FoE[i,j] + T[i,j-1]*FoW[i,j]
        Tplus=T
    return Tplus

if __name__ == "__main__":
    
    print("Coucou SIMUREX")
    