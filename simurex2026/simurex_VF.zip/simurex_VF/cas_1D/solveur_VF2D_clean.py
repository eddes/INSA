# -*- coding: utf-8 -*-
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt

from proprietes import fc_read_geom, fc_indices
from resolution import fc_Fouriers, fc_sparse_Fourier_explicite, fc_VF_numba_Fo

# il faut définir dx, dy et dt
dx = 0.01
dy = dx
dt = 20

print("##########\nRécupération des propriétés à partir de la géométrie (k,rho,Cp, taille)\n")
# on recupere les k,rho,Cp + le contenu des cellules
dossier='./'
fichier ='mur_granit.csv'
file = dossier +  fichier
k,rho,Cp = fc_read_geom(dossier+'materiaux.csv', file, dx)
cells_adiab, cells_ext, cells_int, cells_solide = fc_indices(file)
nx,ny = np.shape(k)[0], np.shape(k)[1]

# on ajoute
cells_CL = np.vstack([cells_ext, cells_int])

print("##########\nAffectation Fouriers + conditions initiales & limites\n")
# calcul des nombres de Fouriers pour 
FoN, FoS, FoE, FoW, u_diag = fc_Fouriers(k, rho, Cp, dt, dx, dy, cells_solide, cells_CL)

# création matrice sparse pour calculer plus rapidement
mat_sparse=fc_sparse_Fourier_explicite(FoN,FoS,FoE,FoW,u_diag, sparse=True)

# Conditions initiales (I.C.) et conditions aux limites (B.C.)
T = np.zeros((nx, ny))
Tplus = T
T_int, T_ext, Tinit = 10, -10, 5

# ici on récupère les indices des cellules intérieures
i_indices, j_indices = cells_int[:, 0], cells_int[:, 1]
T[i_indices, j_indices] = T_int

# ici on récupère les indices des cellules extérieures
i_indices, j_indices = cells_ext[:, 0], cells_ext[:, 1]
T[i_indices, j_indices] = T_ext

# ici on récupère les indices des cellules solides
i_indices, j_indices = cells_solide[:, 0], cells_solide[:, 1]
T[i_indices, j_indices] = Tinit

# pour voir les différentes T à l'instant initial
plt.imshow(T, cmap='jet')

print("##########\nRésolution temporelle\n")
tsimu=3600*1000
temps=np.arange(0, tsimu, dt)

# explicite avec trois méthodes équivalentes 
# on met à plat avant de faire la multiplication matricielle
T=T.flatten()
for t in tqdm(temps):
    
    # le plus efficace : multiplication sparse
    Tplus=mat_sparse.dot(T) 
    
    # la multiplication matricielle avec matrice pleine :
    # Tplus=matriceK.dot(T)
    
    # le plus intuitif : avec les indices [i,j]
    #Tplus = fc_VF_numba_Fo(cells_solide,T,Tplus,FoN,FoS,FoE,FoW,tsimu, dt)
    
    # ensuite on passe au pas de temps suivant 
    T=Tplus

# on remet T au format 2D pour pouvoir tracer
T=T.reshape((nx, ny))

# Création de la figure et du graphique d'isothermes
vmin, vmax = np.min(T), np.max(T)
fig, ax = plt.subplots(figsize=(8, 6))
levels = np.linspace(np.min(T), np.max(T), num=51)  # Par exemple, 51 niveaux uniformément répartis
titre=fichier[:-4]
plt.title (titre)
plt.imshow(T[1:-1,1:-1], cmap='jet')
# plt.imshow(T, cmap='jet')
plt.xlabel('X [m]')
plt.ylabel('Y [m]')

plt.savefig("./" + fichier[:-4] +".png", dpi=200)

