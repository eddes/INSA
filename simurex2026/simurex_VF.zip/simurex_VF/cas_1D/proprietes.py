# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 22:09:27 2026

@author: ewalther01
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def fc_read_geom(fichier_props, fichier_geom, dx):
    
    df_props = pd.read_csv(fichier_props)
    mapping = df_props.set_index('nom')[['lambda', 'rho', 'Cp']].to_dict('index')

    df_geom = pd.read_csv(fichier_geom, sep=',', header=None)
    nx, ny = df_geom.shape
    
    # pour le traitement des CL classiques (adiabatique, h_global etc.) 
    h_ext, h_int =25, 7.7
    #h_ext, h_int = 1e30, 1e30
    k_eq_ext, k_eq_int = h_ext*dx/2, h_int*dx/2
    dict_CL = {'CL_adiab': {'lambda': 1e-30, 'rho': 0, 'Cp': 0},
               'CL_ext': {'lambda': k_eq_ext, 'rho': 0, 'Cp': 0},
               'CL_int': {'lambda': k_eq_int, 'rho': 0, 'Cp': 0}}
    
    def get_prop(nom, prop):
        if nom in dict_CL:
            return dict_CL[nom][prop]
        return mapping.get(nom, {}).get(prop, np.nan)
    
    # Aplatir la grille pour traitement vectoriel
    noms_flat = df_geom.values.ravel()
    k_flat = np.array([get_prop(nom, 'lambda') for nom in noms_flat])
    rho_flat = np.array([get_prop(nom, 'rho') for nom in noms_flat])
    Cp_flat = np.array([get_prop(nom, 'Cp') for nom in noms_flat])

    k = k_flat.reshape(nx, ny)
    rho = rho_flat.reshape(nx, ny)
    Cp = Cp_flat.reshape(nx, ny)
    
    return k,rho,Cp


def fc_indices(geometrie):
    
    # lecture des CL (important le header=None car par defaut pandas enleve 1 ligne)
    df_geom = pd.read_csv(geometrie, header=None)
    contenu = df_geom.values
    # interieur
    idx_CL_int = np.where(contenu  == 'CL_int')
    CL_int = np.column_stack((idx_CL_int[0], idx_CL_int[1]))
    # exterieur
    idx_CL_ext = np.where(contenu  == 'CL_ext')
    CL_ext = np.column_stack((idx_CL_ext[0], idx_CL_ext[1]))
    # adiabatique
    idx_CL_adiab = np.where(contenu  == 'CL_adiab')
    CL_adiab = np.column_stack((idx_CL_adiab[0], idx_CL_adiab[1]))
    
    # ensuite on prend tout ce qui n'est pas de la CL
    exclure = {'CL_ext', 'CL_int', 'CL_adiab'}
    mask = np.ones(contenu.shape, dtype=bool)
    for val in exclure:
        mask &= (contenu != val)

    indices_complement = np.where(mask)
    list_solide = np.column_stack((indices_complement[0], indices_complement[1]))
    # list_solide = np.array(list_solide, dtype=np.int32)
    
    return CL_adiab, CL_ext, CL_int, list_solide 

if __name__ == "__main__":

    
    # Définir le chemin du dossier
    dossier = '../geometrie1D/'
    
    
    dx=0.01
    geometrie = dossier + 'geometrie1D.csv'
    geometrie = dossier + 'acrotere.csv'
    
    #conductivité thermique
    k,rho,Cp = fc_read_geom('./materiaux.csv', geometrie , dx)
    plt.imshow(k, cmap='jet')

    list_CL_adiab, list_CL_ext, list_CL_int , list_solide  = fc_indices(geometrie)
   
    
    