# -*- coding: utf-8 -*-
"""
Created on Tue May 19 08:39:13 2026

@author: ewalther01
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 14:41:01 2026

@author: ewalther01
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import scipy.interpolate as si
from pyepw.epw import EPW

def fc_interpolation(vecteur, temps, temps_voulu):
    # creation fc d'interpolation a partir des donnees
    fc_interp = si.interp1d(temps, vecteur, kind='linear')
    vecteur_voulu= fc_interp(temps_voulu)
    return vecteur_voulu



def fc_lecture_EPW(dossier_epw, fichier_epw, t_CL):
    
    
    epw = EPW()
    epw.read(dossier_epw+ fichier_epw)
    # Vecteur donnant les temperatures*24h 
    # !pip install pyepw
    # https://bigladdersoftware.com/epx/docs/8-3/auxiliary-programs/energyplus-weather-file-epw-data-dictionary.html
    data=epw.weatherdata

    air_vel, Tair, phi_g, Tdew, rain = [],[],[],[],[]
    for wd in data:
        air_vel.append(wd.wind_speed)
        Tair.append(wd.dry_bulb_temperature)
        phi_g.append(wd.global_horizontal_radiation)
        Tdew.append(wd.dew_point_temperature)
    
    Tdew=np.array(Tdew)
    e_sky=0.787 + 0.764*np.log((Tdew+273)/273)
    Tair =np.asarray(Tair)
    Tsky=np.power(e_sky*(Tair+273)**4, 0.25)-273
    t_epw=np.arange(0, len(Tair),1)*3600
    Text_CL=fc_interpolation(Tair, t_epw, t_CL)
    v_air_CL=fc_interpolation(air_vel, t_epw, t_CL)
    phi_g_CL=fc_interpolation(phi_g, t_epw, t_CL)
    Tsky_CL=fc_interpolation(Tsky, t_epw, t_CL)
    
    return Text_CL, phi_g_CL, Tsky_CL, v_air_CL

    
if __name__ == "__main__":
    
        
    # ensuite creation des vecteurs CL au bon echantillonnage temporel
    dt = 600
    simtime=int(3600*24*365-1*3600)
    t_CL = np.arange(0, simtime+dt, dt)
    
    # recuperons la meteo
    dossier="../Fichiers_meteo/"
    fichier="Lyon_Bron.epw"
    Text_CL, phi_g_CL, Tsky_CL, v_air_CL = fc_lecture_EPW(dossier, fichier, t_CL)

    # Créer l'index temporel avec un intervalle de 1200 secondes
    date_debut = '2019-01-01 00:00:00'
    date_fin = '2019-12-31 23:00:00'
    index_temporel = pd.date_range(start=date_debut, end=date_fin, freq=str(dt)+'S')  # 'S' pour secondes

    # Créer un DataFrame avec cet index
    df_interp= pd.DataFrame(index=index_temporel)
    df_interp['Text']=Text_CL
    print("Un affichage...")
    plt.plot(df_interp.index,df_interp.Text)
