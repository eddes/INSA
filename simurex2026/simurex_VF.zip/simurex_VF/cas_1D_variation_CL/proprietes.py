# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 22:09:27 2026

@author: ewalther01
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def fc_read_geom(fichier_props, fichier_geom, dx):
    """Lit les propriétés thermiques des matériaux et la géométrie d'une paroi multicouche en 2D.

    Cette fonction construit des matrices 2D (k, rho, Cp) pour chaque cellule d'une grille.
    Les matériaux sont définis par un fichier CSV de propriétés et un fichier CSV de géométrie.
    Elle gère également des conditions limites spéciales (adiabatique, échange externe/interne)
    en remplaçant les propriétés des matériaux par des valeurs fictives appropriées.

    Args:
        fichier_props (str): Chemin vers un fichier CSV contenant les propriétés des matériaux.
                              Doit avoir les colonnes : 'nom', 'lambda', 'rho', 'Cp'.
                              Exemple :
                                  nom,lambda,rho,Cp
                                  béton,1.75,2300,880
                                  isolation,0.04,50,1200
        fichier_geom (str): Chemin vers un fichier CSV (sans en-tête) décrivant la grille 2D.
                            Chaque cellule contient un nom de matériau (ou un mot-clé spécial :
                            'CL_adiab', 'CL_ext', 'CL_int'). Les dimensions (nx, ny) sont
                            déduites du fichier (shape).
        dx (float): Pas d'espace (taille de maille) en mètres. Utilisé pour calculer les
                    conductivités équivalentes des conditions limites d'échange :
                    `k_eq = h * dx / 2`.
    
    Returns:
        tuple: (k, rho, Cp) trois ndarray de shape (nx, ny) contenant respectivement
               la conductivité thermique (W/m·K), la masse volumique (kg/m³) et la
               capacité thermique massique (J/kg·K) pour chaque cellule.
    
    Notes:
        - Les conditions limites sont gérées via des noms spéciaux dans le fichier de géométrie :
            * 'CL_adiab' : paroi adiabatique (lambda ≈ 0, rho = 0, Cp = 0)
            * 'CL_ext'   : échange externe (conductivité équivalente `k_eq_ext = h_ext * dx / 2`)
            * 'CL_int'   : échange interne (conductivité équivalente `k_eq_int = h_int * dx / 2`)
        - Les coefficients d'échange sont fixés dans la fonction : h_ext = 25 W/m²K, h_int = 7.7 W/m²K.
        - Si un nom de matériau n'est pas trouvé ni dans le mapping ni dans les mots-clés spéciaux,
          la propriété associée est mise à NaN (un avertissement peut être levé en pratique).
        - Les matrices retournées sont organisées selon la grille d'origine (lignes = y, colonnes = x).
    
    Exemple:
        >>> import numpy as np
        >>> import pandas as pd
        >>> # Création de fichiers temporaires
        >>> props_csv = "materiaux.csv"
        >>> with open(props_csv, 'w') as f:
        ...     f.write("nom,lambda,rho,Cp\\nbéton,1.75,2300,880\\nbois,0.15,600,1500")
        >>> geom_csv = "geometrie.csv"
        >>> with open(geom_csv, 'w') as f:
        ...     f.write("béton,béton\\nCL_ext,bois")
        >>> k, rho, Cp = fc_read_geom(props_csv, geom_csv, dx=0.1)
        >>> print(k)
        [[1.75  1.75 ]
         [1.25  0.15]]  # 1.25 = h_ext * dx/2 = 25*0.1/2
    
    Dépendances:
        pandas (pd), numpy (np)
    """
    
    df_props = pd.read_csv(fichier_props)
    mapping = df_props.set_index('nom')[['lambda', 'rho', 'Cp']].to_dict('index')

    df_geom = pd.read_csv(fichier_geom, sep=',', header=None)
    nx, ny = df_geom.shape
    
    # pour le traitement des CL classiques (adiabatique, h_global etc.) 
    h_ext, h_int =25, 7.7
    # h_ext, h_int = 1e30, 1e30 # pour le cas où on veut imposer les températures
    k_eq_ext, k_eq_int = h_ext*dx/2, h_int*dx/2
    dict_CL = {'CL_adiab': {'lambda': 1e-30, 'rho': 0, 'Cp': 0},
               'CL_ext': {'lambda': k_eq_ext, 'rho': 0, 'Cp': 0},
               'CL_int': {'lambda': k_eq_int, 'rho': 0, 'Cp': 0}}
    
    # utile pour la suite : disposer d'une fc "lambda" pour traitement vectoriel
    def get_prop(nom, prop):
        if nom in dict_CL:
            return dict_CL[nom][prop]
        return mapping.get(nom, {}).get(prop, np.nan)
    
    # Aplatir la grille pour traitement vectoriel
    noms_flat = df_geom.values.ravel()
    k_flat = np.array([get_prop(nom, 'lambda') for nom in noms_flat])
    rho_flat = np.array([get_prop(nom, 'rho') for nom in noms_flat])
    Cp_flat = np.array([get_prop(nom, 'Cp') for nom in noms_flat])

    k = k_flat.reshape(nx, ny)
    rho = rho_flat.reshape(nx, ny)
    Cp = Cp_flat.reshape(nx, ny)
    
    return k,rho,Cp


def fc_indices(geometrie):
    
    # lecture des CL (important le header=None car par defaut pandas enleve 1 ligne)
    df_geom = pd.read_csv(geometrie, header=None)
    contenu = df_geom.values
    # interieur
    idx_CL_int = np.where(contenu  == 'CL_int')
    CL_int = np.column_stack((idx_CL_int[0], idx_CL_int[1]))
    # exterieur
    idx_CL_ext = np.where(contenu  == 'CL_ext')
    CL_ext = np.column_stack((idx_CL_ext[0], idx_CL_ext[1]))
    # adiabatique
    idx_CL_adiab = np.where(contenu  == 'CL_adiab')
    CL_adiab = np.column_stack((idx_CL_adiab[0], idx_CL_adiab[1]))
    
    # ensuite on prend tout ce qui n'est pas de la CL
    exclure = {'CL_ext', 'CL_int', 'CL_adiab'}
    mask = np.ones(contenu.shape, dtype=bool)
    for val in exclure:
        mask &= (contenu != val)

    indices_complement = np.where(mask)
    list_solide = np.column_stack((indices_complement[0], indices_complement[1]))
    # list_solide = np.array(list_solide, dtype=np.int32)
    
    return CL_adiab, CL_ext, CL_int, list_solide 

if __name__ == "__main__":

    
    # Définir le chemin du dossier
    dossier = '../geometrie1D/'
    
    
    dx=0.01
    geometrie = dossier + 'geometrie1D.csv'
    geometrie = dossier + 'acrotere.csv'
    
    #conductivité thermique
    k,rho,Cp = fc_read_geom('./materiaux.csv', geometrie , dx)
    plt.imshow(k, cmap='jet')

    list_CL_adiab, list_CL_ext, list_CL_int , list_solide  = fc_indices(geometrie)
   
    
    