# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 22:09:27 2026

@author: ewalther01
"""
from numba import njit
import numpy as np
import scipy.sparse as sp
from tqdm import tqdm

def fc_Euler_Implicit(Tinit, matrice_FoX, dt, simtime):
    # boucle Euler implicite
    t_range=np.arange(0,simtime,dt)
    T=Tinit
    for t in tqdm(t_range):
        T_plus = sp.linalg.spsolve(matrice_FoX, T)
        T=T_plus
    return T

def fc_Fouriers(k,rho,Cp,dt,dx,dy,cells_solide, cells_CL):
    """Calcule les nombres de Fourier (conductances thermiques sans dimension) pour chaque maille d'une grille 2D.

    Cette fonction prépare les coefficients nécessaires à un schéma temporel implicite (Euler)
    pour la résolution de l'équation de la chaleur en 2D. Elle prend en compte la moyenne harmonique
    des conductivités entre cellules voisines pour assurer la continuité du flux. Les mailles solides
    sont distinguées des mailles de conditions limites (CL).

    Les nombres de Fourier calculés sont :
        - FoN : conductance vers le Nord (i-1, j)
        - FoS : conductance vers le Sud (i+1, j)
        - FoE : conductance vers l'Est  (i, j+1)
        - FoW : conductance vers l'Ouest (i, j-1)

    Le coefficient diagonal `u_diag` vaut `1 - (FoN+FoS+FoE+FoW)` pour les cellules solides,
    et `1` pour les cellules de CL (ainsi la température reste inchangée sur ces mailles).

    Args:
        k (ndarray): Matrice 2D (nx, ny) des conductivités thermiques (W/m·K) pour chaque maille.
        rho (ndarray): Matrice 2D des masses volumiques (kg/m³).
        Cp (ndarray): Matrice 2D des capacités thermiques massiques (J/kg·K).
        dt (float): Pas de temps (s).
        dx (float): Pas d'espace horizontal (m).
        dy (float): Pas d'espace vertical (m).
        cells_solide (ndarray): Tableau de shape (n_cells, 2) contenant les indices (i, j)
                                 des mailles qui appartiennent au domaine solide (non CL).
        cells_CL (ndarray): Tableau de shape (n_CL, 2) contenant les indices (i, j)
                            des mailles où on impose une condition limite (température fixe ou adiabatique).

    Returns:
        tuple: (FoN, FoS, FoE, FoW, u_diag) où chaque élément est une matrice ndarray de shape (nx, ny).
            - FoN, FoS, FoE, FoW : nombres de Fourier sans dimension pour chaque direction.
            - u_diag : coefficient diagonal pour le système linéaire (sans dimension).

    Notes:
        - Le produit de contrôle volumique pour une maille est : `dx * dy`.
        - La capacité thermique totale de la maille : `mCp = rho * Cp * dx * dy`.
        - La conductance thermique entre deux mailles utilise une moyenne harmonique des conductivités,
          par exemple pour la direction Sud :
            `G = 1 / (0.5 * dy * (1/k[i+1,j] + 1/k[i,j]))`
          puis le nombre de Fourier associé est :
            `FoS = dx * dt / (mCp) * G` (formulation avec `dx` car la section est `dx * 1` en 2D).
        - Les cellules de condition limite (`cells_CL`) se voient attribuer `u_diag = 1`, ce qui revient
          à fixer leur température (équivalent à un coefficient diagonal de 1 et aucun terme source).

    Exemple:
        >>> import numpy as np
        >>> nx, ny = 3, 4
        >>> k = np.ones((nx, ny)) * 2.0
        >>> rho = np.ones((nx, ny)) * 2000
        >>> Cp = np.ones((nx, ny)) * 800
        >>> dt, dx, dy = 0.1, 0.05, 0.05
        >>> cells_solide = np.array([[1,1], [1,2]])
        >>> cells_CL = np.array([[0,0], [2,3]])
        >>> FoN, FoS, FoE, FoW, u_diag = fc_Fouriers(k, rho, Cp, dt, dx, dy, cells_solide, cells_CL)
        >>> print(FoN.shape)  # (3, 4)
        >>> print(u_diag[0,0])  # 1.0 (car CL)
    """

    nx,ny = k.shape[0],k.shape[1]
    FoS, FoN, FoE, FoW, u_diag = np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny)),np.zeros((nx,ny))
    dxdy=dx*dy
    for m in range(len(cells_solide)):
        i,j = cells_solide[m, 0], cells_solide[m, 1]
        mCp=rho[i,j]*Cp[i,j]*dxdy
        FoS[i,j] = dx*dt/(mCp* 0.5*dy*(1/k[i+1,j] + 1/k[i,j]))
        FoN[i,j] = dx*dt/(mCp* 0.5*dy*(1/k[i-1,j] + 1/k[i,j]))
        FoE[i,j] = dy*dt/(mCp* 0.5*dx*(1/k[i,j+1] + 1/k[i,j]))
        FoW[i,j] = dy*dt/(mCp* 0.5*dx*(1/k[i,j-1] + 1/k[i,j]))
        u_diag[i,j] = 1-(FoS[i,j]+FoN[i,j]+FoE[i,j]+FoW[i,j])
    
    # pour les CL on doit mettre un coeff de 1 pour que T+ = T
    for m in range(len(cells_CL)):
        i,j = cells_CL[m, 0], cells_CL[m, 1]
        u_diag[i,j]=1
        
    return FoN, FoS, FoE, FoW, u_diag

# creation de la matrice sparse pour résolution explicite
def fc_sparse_Fourier_explicite(FoN,FoS,FoE,FoW,u_diag, sparse=True):
    
    """Assemble la matrice des coefficients (pleine ou creuse) pour la résolution du système thermique implicite.

   Cette fonction construit la matrice du système linéaire `A * T_plus = T` à partir des nombres de Fourier
   et du coefficient diagonal calculés par `fc_Fouriers`. La matrice est organisée en 2D aplatie
   (chaque maille `(i,j)` correspond à l'indice `i*ny + j`). Les connections entre voisins sont assurées
   par des diagonales décalées (Nord, Sud, Est, Ouest). La fonction permet de retourner une matrice
   creuse (format `scipy.sparse.diags`) ou une matrice pleine (numpy).

   Args:
       FoN (ndarray): Matrice 2D (nx, ny) des nombres de Fourier vers le Nord (i-1, j).
       FoS (ndarray): Matrice 2D (nx, ny) des nombres de Fourier vers le Sud (i+1, j).
       FoE (ndarray): Matrice 2D (nx, ny) des nombres de Fourier vers l'Est (i, j+1).
       FoW (ndarray): Matrice 2D (nx, ny) des nombres de Fourier vers l'Ouest (i, j-1).
       u_diag (ndarray): Matrice 2D (nx, ny) du coefficient diagonal.
       sparse (bool, optional): Si True (défaut), retourne une matrice creuse `scipy.sparse.dia_matrix`.
                                Si False, retourne une matrice pleine (numpy ndarray).

   Returns:
       scipy.sparse.dia_matrix ou ndarray: Matrice de taille (N, N) où `N = nx * ny`.
           Si `sparse=True` : matrice diagonale creuse (dia_matrix) pour le système implicite.
           Si `sparse=False` : matrice pleine (numpy.array) équivalente.

   Notes:
       - Les matrices d'entrée sont aplaties en vecteurs de taille N.
       - Les diagonales sont décalées selon les règles suivantes :
           * Nord (i-1) : décalage de `-col` (col = ny)
           * Sud (i+1) : décalage de `+col`
           * Est  (j+1) : décalage de `+1`
           * Ouest (j-1) : décalage de `-1`
       - Les éléments aux bords sont ignorés lors de la construction creuse (les diagonales sont tronquées).
       - La matrice creuse est construite avec `scipy.sparse.diags` ; la matrice pleine l'est par somme de
         matrices `np.eye(k)*diag`.
       - Cette matrice est typiquement utilisée dans un schéma d'Euler implicite pour l'équation de la chaleur.

   Exemple:
       >>> import numpy as np
       >>> from scipy import sparse as sp
       >>> nx, ny = 3, 3
       >>> FoN = np.ones((nx, ny)) * 0.1
       >>> FoS = np.ones((nx, ny)) * 0.1
       >>> FoE = np.ones((nx, ny)) * 0.1
       >>> FoW = np.ones((nx, ny)) * 0.1
       >>> u_diag = np.ones((nx, ny)) * 0.6
       >>> mat = fc_sparse_Fourier_explicite(FoN, FoS, FoE, FoW, u_diag, sparse=True)
       >>> print(mat.shape)  # (9, 9)
       >>> mat_dense = fc_sparse_Fourier_explicite(FoN, FoS, FoE, FoW, u_diag, sparse=False)
       >>> print(mat_dense[0,0])  # 0.6
   """
    
    nx,ny=FoS.shape[0],FoS.shape[1]
    size, col = nx*ny, ny
    # on applatit les matrices en vecteurs
    FoS=FoS.flatten()
    FoN=FoN.flatten()
    FoE=FoE.flatten()
    FoW=FoW.flatten()
    u_diag=u_diag.flatten()
    
    #Décalage des diagonales pour faire correspondre les indices
    N_diag = np.roll(FoN,-col)
    S_diag = np.roll(FoS,+col)
    E_diag = np.roll(FoE,+1)
    W_diag = np.roll(FoW,-1)
    
    # Matrice pleine pour la forme
    if not sparse:
        matriceK = np.eye(size,k=-col)*N_diag \
                 + np.eye(size,k=-1)*W_diag \
                 + np.eye(size)*u_diag \
                 + np.eye(size,k=1)*E_diag \
                 + np.eye(size,k=col)*S_diag
    
    # Décalage des diagonales
    N_diag = N_diag[:-col]
    S_diag = S_diag[col:]
    E_diag = E_diag[1:]
    W_diag = W_diag[:-1]
    # On assemble
    mat_sparse = sp.diags(
            [N_diag, W_diag, u_diag, E_diag, S_diag],
            offsets=[-col,-1, 0, +1, +col],
            shape=(size, size)
        )
    
    # ensuite 
    if sparse:
        return mat_sparse
    else:
        return matriceK
    
def fc_sparse_Fourier_implicite(FoN,FoS,FoE,FoW,u_diag):
    
    nx,ny=FoS.shape[0],FoS.shape[1]
    size, col = nx*ny, ny
    # on applatit les matrices en vecteurs
    FoS=FoS.flatten()
    FoN=FoN.flatten()
    FoE=FoE.flatten()
    FoW=FoW.flatten()
    u_diag=u_diag.flatten()
    
    somme_Fo = 1+ FoS+FoN+FoE+FoW
    terme_N = FoN/somme_Fo
    terme_S = FoS/somme_Fo
    terme_E = FoE/somme_Fo
    terme_W = FoW/somme_Fo
    terme_diag = 1/somme_Fo
    #Décalage des diagonales pour faire correspondre les indices
    N_diag = np.roll(terme_N,-col)
    S_diag = np.roll(terme_S,+col)
    E_diag = np.roll(terme_E,+1)
    W_diag = np.roll(terme_W,-1)
        
    # Décalage des diagonales
    N_diag = N_diag[:-col]
    S_diag = S_diag[col:]
    E_diag = E_diag[1:]
    W_diag = W_diag[:-1]
    # On assemble
    mat_sparse = sp.diags(
            [N_diag, W_diag, terme_diag, E_diag, S_diag],
            offsets=[-col,-1, 0, +1, +col],
            shape=(size, size)
        )
    
    return mat_sparse

# version naive du calcul "matriciel" : pour la compréhension du calcul mais pas efficace
@njit
def fc_VF_numba_Fo(cells_mur, T,Tplus,FoN,FoS,FoE,FoW,tsimu, dt):
    for t in np.arange(0, tsimu, dt):
        for ij in cells_mur :
            i,j = ij[0], ij[1]
            Tplus[i,j]= T[i,j]*(1-FoN[i,j]-FoS[i,j]-FoE[i,j]-FoW[i,j]) \
                + T[i+1,j]*FoS[i,j] + T[i-1,j]*FoN[i,j] \
                    + T[i,j+1]*FoE[i,j] + T[i,j-1]*FoW[i,j]
        Tplus=T
    return Tplus

if __name__ == "__main__":
    
    print("Coucou SIMUREX")
    