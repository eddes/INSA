# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 14:41:01 2026

@author: ewalther01
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import scipy.interpolate as si
from pyepw.epw import EPW

def fc_interpolation(vecteur, temps, temps_voulu):
    """Interpole linéairement un vecteur de données en fonction du temps.

    Cette fonction construit une fonction d'interpolation linéaire à partir
    de couples (temps, vecteur) et l'évalue aux instants demandés.

    Args:
        vecteur (array_like): Valeurs de la grandeur à interpoler (par ex. teneur en eau,
                              température, etc.). Doit avoir la même longueur que `temps`.
        temps (array_like): Coordonnées temporelles des points connus (abscisses). 
                            Supposées strictement croissantes.
        temps_voulu (float ou array_like): Instant(s) pour le(s)quel(s) on souhaite
                                           obtenir la valeur interpolée. Peut être un scalaire
                                           ou un tableau.

    Returns:
        float ou ndarray: Valeur(s) interpolée(s) aux temps demandés. Même forme que `temps_voulu`.

    Example:
        >>> import numpy as np
        >>> t = np.array([0, 1, 2])
        >>> y = np.array([10, 12, 15])
        >>> fc_interpolation(y, t, 1.5)
        13.5

    Note:
        Cette fonction utilise `scipy.interpolate.interp1d` avec l'option `kind='linear'`.
        Il est donc nécessaire d'avoir importé `scipy.interpolate` comme `si` au préalable :
        ```python
        import scipy.interpolate as si
    """
    # creation fc d'interpolation a partir des donnees
    fc_interp = si.interp1d(temps, vecteur, kind='linear')
    vecteur_voulu= fc_interp(temps_voulu)
    return vecteur_voulu


def fc_lecture_EPW(dossier_epw, fichier_epw, t_CL):
    
    """Lit un fichier météo EPW, extrait les grandeurs pertinentes et les interpole aux instants demandés.

    Cette fonction utilise la bibliothèque `pyepw` pour lire un fichier EPW (EnergyPlus Weather).
    Elle extrait la vitesse du vent, la température de l'air sec, le rayonnement horizontal global
    et la température du point de rosée. Elle calcule ensuite la température de ciel (`Tsky`)
    selon une formule empirique (Clark & Allen, aussi dans Duffie & Beckman). Enfin, toutes les variables sont interpolées
    linéairement aux temps spécifiés par `t_CL` (en secondes).

    Args:
       dossier_epw (str): Chemin du dossier contenant le fichier EPW.
       fichier_epw (str): Nom du fichier EPW (extension .epw).
       t_CL (float ou array_like): Temps souhaités (en secondes) pour l'interpolation.
                                   Les valeurs doivent être comprises entre 0 et la durée
                                   totale du fichier EPW (nombre d'heures * 3600).

    Returns:
       tuple: (Text_CL, phi_g_CL, Tsky_CL, v_air_CL) où chaque élément est un ndarray
              ou une valeur scalaire (selon la forme de `t_CL`).
           - Text_CL : Température de l'air sec interpolée (°C).
           - phi_g_CL : Rayonnement horizontal global interpolé (W/hm2:- unité EPW).
           - Tsky_CL : Température de ciel interpolée (°C).
           - v_air_CL : Vitesse du vent interpolée (m/s).

    Exemple:
       >>> from fc_interpolation import fc_interpolation  # (fonction auxiliaire)
       >>> import numpy as np
       >>> Text, phi, Tsky, v = fc_lecture_EPW('./data/', 'FRA_Lyon.epw', np.array([3600, 7200]))
       >>> print(Text)
       [12.5, 13.2]

    Note:
       - Nécessite la bibliothèque `pyepw` : `pip install pyepw`.
       - La formule de `Tsky` utilisée est : 
         `Tsky = ( e_sky * (Tair+273)^4 )^{0.25} - 273`
         avec `e_sky = 0.787 + 0.764 * ln((Tdew+273)/273)`.
       - La fonction d'interpolation sous-jacente est `fc_interpolation` (linéaire).
       - Les données EPW sont horaires ; la conversion en secondes se fait via `t_epw = np.arange(0, len(Tair), 1)*3600`.
   """
    epw = EPW()
    epw.read(dossier_epw+ fichier_epw)
    # Vecteur donnant les temperatures*24h 
    # !pip install pyepw
    # https://bigladdersoftware.com/epx/docs/8-3/auxiliary-programs/energyplus-weather-file-epw-data-dictionary.html
    data=epw.weatherdata

    air_vel, Tair, phi_g, Tdew = [],[],[],[]
    for wd in data:
        air_vel.append(wd.wind_speed)
        Tair.append(wd.dry_bulb_temperature)
        phi_g.append(wd.global_horizontal_radiation)
        Tdew.append(wd.dew_point_temperature)
    
    # petit calcul de Tsky pour le plaisir
    Tdew=np.array(Tdew)
    e_sky=0.787 + 0.764*np.log((Tdew+273)/273)
    Tair =np.asarray(Tair)
    Tsky=np.power(e_sky*(Tair+273)**4, 0.25)-273 
    t_epw=np.arange(0, len(Tair),1)*3600 # conversion en secondes 
    Text_CL=fc_interpolation(Tair, t_epw, t_CL)
    v_air_CL=fc_interpolation(air_vel, t_epw, t_CL)
    phi_g_CL=fc_interpolation(phi_g, t_epw, t_CL)
    Tsky_CL=fc_interpolation(Tsky, t_epw, t_CL)
    
    return Text_CL, phi_g_CL, Tsky_CL, v_air_CL

    
if __name__ == "__main__":
    
        
    # ensuite creation des vecteurs CL au bon echantillonnage temporel
    dt = 600
    simtime=int(3600*24*365-1*3600)
    t_CL = np.arange(0, simtime+dt, dt)
    
    # recuperons la meteo
    dossier="../Fichiers_meteo/"
    fichier="Lyon_Bron.epw"
    Text_CL, phi_g_CL, Tsky_CL, v_air_CL = fc_lecture_EPW(dossier, fichier, t_CL)

    # Créer l'index temporel avec un intervalle de 1200 secondes
    date_debut = '2019-01-01 00:00:00'
    date_fin = '2019-12-31 23:00:00'
    index_temporel = pd.date_range(start=date_debut, end=date_fin, freq=str(dt)+'S')  # 'S' pour secondes

    # Créer un DataFrame avec cet index
    df_interp= pd.DataFrame(index=index_temporel)
    df_interp['Text']=Text_CL
    print("Un affichage...")
    plt.plot(df_interp.index,df_interp.Text)
